package linkedList;

import custom_exceptions.LinkedListException;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class LinkedList {
    
	private Node head;
    
	// 1. method to add elements into list in sorted order.
    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        
        if(head.data >= data) {
        	newNode.next = head.next;
        	head.next = newNode;
        	return;
        }

        Node current = head;
        while (current.next != null && current.next.data < data) {
            current = current.next;
        }

        if(current.next != null && current.next.data >= data) {
        	
        	newNode.next = current.next;
        	current.next = newNode;
        	return;
        	
        }
        	
        current.next = newNode;
    }
    
    // 2. method to remove all occurrences of given element X in removeAll(X) method.
    public void removeAll(int data) throws LinkedListException {
    	
    	if(head==null)
    		throw new LinkedListException("List is Empty , CANNOT remove any element !!");
    	
        Node current = head;

        while (current != null && current.data == data) {
            head = current.next;
            current = head;
        }

        while (current != null && current.next != null) {
            if (current.next.data == data) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }
    }
    
    // 3. method to find index of given element X in find(X) method.
    public int find(int data) throws LinkedListException {
        Node current = head;
        int position = 0;

        while (current != null) {
            if (current.data == data) {
                return position;
            }
            current = current.next;
            position++;
        }

        return -1;
    }
    
    // 4. method to return comma separated elements from start to end.
    public String toString() {
    	
    	if(head == null)
    		return "[]";
        
        Node current = head;
        String result = "[";

        while (current != null) {
            result = result + current.data + ",";
            current = current.next;
        }

        if (result.length() > 0) {
            result = result.substring(0, result.length() - 1);
            result = result + "]";
        }

        return result.toString();
    }
    
}

