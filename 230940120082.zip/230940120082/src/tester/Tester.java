package tester;

import linkedList.LinkedList;

public class Tester {

	public static void main(String[] args) {

		LinkedList list = new LinkedList();

		System.out.println("Adding Random integer numbers into List in Sorted Order :-");
		
		list.add(10);
		list.add(30);
		list.add(50);
		list.add(20);
		list.add(50);
		list.add(80);
		list.add(60);
		list.add(50);

		try {

			// elements will be added in sorted order.
			System.out.println("list: " + list.toString());

			// for removeAll() method, using a integer variable named elementToBeRemoved,
			// here the value of this variable is 50.
			int elementToBeRemoved = 50;

			// Implementing removeAll() method, giving elementToBeRemoved value to the
			// removeAll() method.
			list.removeAll(elementToBeRemoved);

			// printing list after removing all occurrences of 50.
			System.out.println("list AFTER removing all " + elementToBeRemoved + "s : " + list.toString());

			// creating a variable which will be given to find() method to find the index of
			// this variable within the list,
			// here the value of elementIndexToBeFound is 60.
			int elementIndexToBeFound = 60;

			// implementing find() method.
			int resultOfFindMethod = list.find(elementIndexToBeFound);

			// printing the index of the elementToBeFound element, if the element is not
			// found then -1 is returned.
			if(resultOfFindMethod!=-1)
				System.out.println("Index of element " + elementIndexToBeFound + " is: " + ++resultOfFindMethod);
			else
				System.out.println("element " + elementIndexToBeFound + " does NOT exist in the List !!");
			
			// implementing toString().
			System.out.println("toString of the linked list: " + list.toString());

		} catch (Exception e) {

			System.out.println(e);

		}

	}

}
