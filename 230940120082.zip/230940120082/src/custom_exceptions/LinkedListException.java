package custom_exceptions;

@SuppressWarnings("serial")
public class LinkedListException extends Exception {

	public LinkedListException(String mesg) {
		
		super(mesg);
		
	}
	
}
